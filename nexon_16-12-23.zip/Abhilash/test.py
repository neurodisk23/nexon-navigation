import numpy as np
from novatel_oem7_msgs.msg import BESTPOS
from novatel_oem7_msgs.msg import BESTVEL
from novatel_oem7_msgs.msg import INSPVA
import rospy
from std_msgs.msg import String
import actuator
import math
import pid
import time




obj = actuator.controller("169.254.178.227",5001)
obj.connect()



while(True):
    steering_feedback = obj.receive_data().split(',')
    print("steering feedback:",steering_feedback)