import rospy
import numpy as np
from  novatel_oem7_msgs.msg import BESTPOS, CORRIMU,BESTVEL
from std_msg.msg import float64
#!/usr/bin/env python3

global acceleration, speed

def corrimu_callback(data):
    # Callback function for CORRIMU topic
    lateral_acc = data.lateral_acc
    longitudinal_acc = data.longitudinal_acc
    acceleration = np.sqrt(lateral_acc**2 + longitudinal_acc**2)
    rospy.loginfo("Acceleration on ego vehicle:\n%s m/sec2", acceleration)

def bestvel_callback(data):
    # Callback function for BESTVEL topic
    speed = data.hor_speed * (18/5)
    rospy.loginfo("Velocity of the Ego Vehicle:\n%s m/sec",speed )
    

def listener():
    rospy.init_node('listener', anonymous=True)


    # Subscribe to CORRIMU topic
    rospy.Subscriber('/novatel/oem7/corrimu', CORRIMU, corrimu_callback)

    # Subscribe to BESTVEL topic
    rospy.Subscriber('/novatel/oem7/bestvel', BESTVEL, bestvel_callback)

    rospy.spin()

if __name__ == '__main__':
    listener()
