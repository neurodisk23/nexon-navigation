#!/usr/bin/env python3
import numpy as np
import rospy
from novatel_oem7_msgs.msg import CORRIMU, BESTVEL  # Replace with the actual message types

def data_callback(data, topic_name):
    # Callback function for both topics
    if topic_name == 'CORRIMU':
        acceleration = np.sqrt(data.lateral_acc**2 + data.longitudinal_acc**2)
        #rospy.loginfo("CORRIMU Data Received:\nAcceleration: %f m/sec2", acceleration)
    elif topic_name == 'BESTVEL':
        rospy.loginfo("BESTVEL Data Received:\nHorizontal Speed: %f m/sec", data.hor_speed)

def listener():
    rospy.init_node('listener', anonymous=True)

    # Subscribe to CORRIMU topic
    rospy.Subscriber('/novatel/oem7/corrimu', CORRIMU, lambda data: data_callback(data, 'CORRIMU'))

    # Subscribe to BESTVEL topic
    rospy.Subscriber('/novatel/oem7/bestvel', BESTVEL, lambda data: data_callback(data, 'BESTVEL'))

    rospy.spin()

if __name__ == '__main__':
    listener()
