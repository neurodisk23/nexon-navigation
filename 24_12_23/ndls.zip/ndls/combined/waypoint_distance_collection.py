#!/usr/bin/env python

import rospy
from novatel_oem7_msgs.msg  import BESTPOS
from std_msgs.msg import String
from datetime import datetime
from geopy.distance import geodesic

print("Collecting Waypoints in the format Latitude, Longitide, Distance between current and previous waypoint ")

current_datetime = datetime.now()

# Format the date as hh-mm-dd-mm-yyyy
formatted_date = current_datetime.strftime("%H-%M-%d-%m-%Y")
class GPSDataLogger:
    def __init__(self):
        self.latitude = 0.0
        self.longitude = 0.0
        self.data_list = []

        # Set up ROS node
        rospy.init_node('gps_data_logger', anonymous=True)

        # Subscriber to the /novatel/oem7/bestpos topic
        rospy.Subscriber('/novatel/oem7/bestpos', BESTPOS, self.bestpos_callback)

        # File to save the data
        self.output_file = "gps_data_"+formatted_date+".txt"

        # Previous coordinates for distance calculation
        self.prev_coords = None

    def bestpos_callback(self, msg):
        # Extract latitude and longitude from the BESTPOS message
        current_coords = (msg.lat, msg.lon)

        # Calculate distance from previous coordinates
        distance = 0.0
        if self.prev_coords is not None:
            distance = geodesic(self.prev_coords, current_coords).meters

        # Append the data to the list
        self.data_list.append((msg.lat, msg.lon, distance))

        # Save the data to a text file
        self.save_to_file()

        # Update previous coordinates
        self.prev_coords = current_coords

        rospy.sleep(0.25)

    def save_to_file(self):
        with open(self.output_file, 'w') as file:
            for data_point in self.data_list:
                file.write(f"[{data_point[0]}, {data_point[1]}, {data_point[2]}]\n")

if __name__ == '__main__':
    try:
        gps_logger = GPSDataLogger()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass
