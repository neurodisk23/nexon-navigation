import numpy as np
from novatel_oem7_msgs.msg import BESTPOS
from novatel_oem7_msgs.msg import BESTVEL
from novatel_oem7_msgs.msg import INSPVA
from std_msgs.msg import Float64

import rospy
from std_msgs.msg import String


lat = 0
lng = 0
heading = 0
wp_threshold = 1.111395e5
#GNSS position

def callback_required_dynamics(data):
    global required_dynamics
    print(data.data)
    required_dynamics = data.data

def callback_latlong(data):
    global lat,lng
    lat = data.lat
    lng = data.lon

#GNSS heading
def callback_heading(data):

    global heading
    heading=data.azimuth  
rospy.init_node('IDM_Actuation', anonymous=True)
#ROS subscription
rospy.Subscriber("/novatel/oem7/bestpos",BESTPOS, callback_latlong)
rospy.Subscriber("/novatel/oem7/inspva",INSPVA, callback_heading)
rospy.Subscriber("/required_dynamics", Float64, callback_required_dynamics)

#TCP connection







'''message = "A,N,0,0,0,0,0,0,0,0,0\r\n" 
obj.send_data(message)
feed = obj.receive_data()
print(feed)
message = "A,N,0,1,100,0,0,0,0,0,0\r\n"
obj.send_data(message)
time.sleep(1)
feed = obj.receive_data()
print(feed)
message = "A,D,0,0,0,0,0,0,0,0,0 \r\n"
obj.send_data(message)
feed = obj.receive_data()
print(feed)'''
while not rospy.is_shutdown():
    try:
        if required_dynamics > 0 :
            print("Required_dynamics", required_dynamics)
            print("\n")
        else:
            steer_angle = 0
            obj.send_data('A,N,0,1,100,0,0,0,0,0,0\r\r')
            time.sleep(1)
        
        
    except rospy.ROSInterruptException:
        pass