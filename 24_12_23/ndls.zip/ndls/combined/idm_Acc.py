import rospy
import numpy as np 
from std_msgs.msg import Float64
from novatel_oem7_msgs.msg import CORRIMU, BESTVEL
import time 
file_name = "file.txt"

t  = 3
a  = 1.5
b  = 2
s0 = 10
desired_velocity = 15 * 0.277778


def gap(current_velocity, relative_velocity):
    return s0 + current_velocity*t + current_velocity*relative_velocity/(2*np.sqrt(a*b))

def idm_acc(desired_velocity, current_velocity, relative_gap, relative_velocity):
    return a*(1 -  (current_velocity/desired_velocity)**4 - (gap(current_velocity,relative_velocity)/relative_gap)**2)


def data_callback(data, topic_name):
    global vehicle_speed_relative
    global vehicle_speed
    global vehicle_relative_gap
    global acceleration

    # Callback function for both topics
    if topic_name == 'relative_speed':
        vehicle_speed_relative = data.data
        #print("\n Vehicle Relative Velocity :", vehicle_speed_relative)
        # rospy.loginfo("CORRIMU Data Received:\nAcceleration: %f m/sec2", acceleration)
    elif topic_name == 'CORRIMU':
        acceleration = np.sqrt(data.lateral_acc**2 + data.longitudinal_acc**2)
        print('\n The Ego vehicle acceleration is :',acceleration," m/sec2")
    elif topic_name == 'BESTVEL':
        vehicle_speed = data.hor_speed
        #print("\n EgO Vehicle Velocity: ", vehicle_speed)
    elif topic_name == 'relative_gap':
        vehicle_relative_gap = data.data
        #rint("\n Relative Gap: ",vehicle_relative_gap)


    required_dynamics = idm_acc(desired_velocity,vehicle_speed,vehicle_relative_gap,vehicle_speed_relative)
    print("\n EgO Vehicle Required Acceleration : ",required_dynamics," m/sec2")

    value = [acceleration,required_dynamics]
    with open("file_output.txt","a") as file :
        file.write(str(value) + ", \n")
    

def listener():
    rospy.init_node('IDM', anonymous=True)
    

    # Subscribe to CORRIMU topic
    rospy.Subscriber('/novatel/oem7/bestvel', BESTVEL, lambda data: data_callback(data, 'BESTVEL'))
    
    rospy.Subscriber('/novatel/oem7/corrimu', CORRIMU, lambda data: data_callback(data, 'CORRIMU'))

    # Subscribe to BESTVEL topic
    rospy.Subscriber('/Vehicle_speed_m/sec', Float64, lambda data: data_callback(data, 'relative_speed'))

    rospy.Subscriber('/Vehicle_Gap', Float64, lambda data: data_callback(data, 'relative_gap'))

    rospy.spin()

if __name__ == '__main__':
    listener()
