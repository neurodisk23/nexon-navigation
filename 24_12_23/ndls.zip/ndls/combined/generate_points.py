from scipy.interpolate import CubicSpline
import numpy as np
import matplotlib.pyplot as plt
import math
from geopy.distance import geodesic

def calculate_control_points(point_a, point_b, num_control_points, side_factor):
    # Calculate the bearing from A to B
    bearing_ab = calculate_bearing(point_a, point_b)

    # Calculate the distance between A and B
    distance_ab = geodesic(point_a, point_b).kilometers

    # Calculate the step size for control points
    step_size = distance_ab / (num_control_points + 1)

    # Generate control points along AB
    control_points = []
    for i in range(1, num_control_points + 1):
        distance_i = i * step_size * side_factor
        point_i = geodesic(kilometers=distance_i).destination(point_a, bearing_ab)
        control_points.append(point_i)

    return control_points

def calculate_bearing(point_a, point_b):
    delta_lon = point_b[1] - point_a[1]
    x = math.cos(math.radians(point_b[0])) * math.sin(math.radians(delta_lon))
    y = math.cos(math.radians(point_a[0])) * math.sin(math.radians(point_b[0])) - \
        math.sin(math.radians(point_a[0])) * math.cos(math.radians(point_b[0])) * math.cos(math.radians(delta_lon))
    bearing = math.atan2(x, y)
    return math.degrees(bearing)

def calculate_perpendicular_point(point, bearing, distance):
    # Calculate the perpendicular point at a distance from the given point
    perpendicular_bearing = bearing - 90
    perpendicular_point = geodesic(kilometers=distance / 1000).destination(point, perpendicular_bearing)
    return perpendicular_point


def calculate_points(point_a, point_b, num_control_points, side_factor):
  control_points = calculate_control_points(point_a, point_b, num_control_points, side_factor)
  bearing_ab = calculate_bearing(point_a, point_b)
  perpendicular_points = [calculate_perpendicular_point(control_point, bearing_ab, distance_from_control) for control_point in control_points]

  return perpendicular_points



point_a = (17.601546546225503, 78.12661291996469)  # Coordinates of point A
point_b = (17.601796774587033, 78.12660298418811)  # Coordinates of point B

# Specify the number of control points
num_control_points = 3

# Specify the side factor (-1 for left, 1 for right)
side_factor = 1

# Calculate the perpendicular points at 4m from each control point
distance_from_control = 4
# Calculate the control points along AB
control_points = calculate_points(point_a, point_b, num_control_points, side_factor)

print(control_points)