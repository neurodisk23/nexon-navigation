import numpy as np
from novatel_oem7_msgs.msg import BESTPOS
from novatel_oem7_msgs.msg import BESTVEL
from novatel_oem7_msgs.msg import INSPVA
from std_msgs.msg import Float64
import rospy
from std_msgs.msg import String
import actuator
import math
import pid
import time

obj = actuator.controller("169.254.178.227",5001)
obj.connect()

# Global variables
lat = 0
lng = 0
heading = 0
required_dynamics = 0  # Initialize the variable



# Callback function for required dynamics
def callback_required_dynamics(data):
    global required_dynamics
    required_dynamics = data.data


# Callback functions for GNSS data
def callback_latlong(data):
    global lat, lng
    lat = data.lat
    lng = data.lon

def callback_heading(data):
    global heading
    heading = data.azimuth

rospy.init_node('IDM_Actuation', anonymous=True)

# ROS subscriptions
rospy.Subscriber("/novatel/oem7/bestpos", BESTPOS, callback_latlong)
rospy.Subscriber("/novatel/oem7/inspva", INSPVA, callback_heading)
rospy.Subscriber("/required_dynamics", Float64, callback_required_dynamics)

def dynamics(required_dynamics):
    print("\n Required Dynamics : ", required_dynamics)
    if required_dynamics >= 0 :
        acc = int(required_dynamics*10)
        if acc >100:
            acc = 90
        print("\n Accelerating : ",acc)
        message = "A1,D,"+str(acc)+",0,0,0,0,0,0,0,0\r\n"
                
    else :
        dec = int(required_dynamics*(-20))
        if dec > 90 :
            dec = 90
        print("\n Deaccelerating : ",dec)
        message = "A3,D,0,1,"+str(dec)+",0,0,0,0,0,0\r\n"
    return message



print(1)
message = "A,N,0,0,0,0,0,0,0,0,0\r\n" 
obj.send_data(message)
# feed = obj.receive_data()
# print(feed)
print(2)
message = "A,N,0,1,70,0,0,0,0,0,0\r\n"
obj.send_data(message)
time.sleep(1)
feed = obj.receive_data()
print(feed)
print(3)
message = "A,D,0,0,0,0,0,0,0,0,0 \r\n"
obj.send_data(message)
feed = obj.receive_data()
print(feed)
time.sleep(1)
message = "A,D,10,1,0,0,0,0,0,0,0 \r\n"
obj.send_data(message)
feed = obj.receive_data()
print(feed)
time.sleep(1)
print(4)
message = "A,D,10,1,0,0,0,0,0,0,0 \r\n"
obj.send_data(message)
feed = obj.receive_data()
print(feed)
time.sleep(1)
print(4.1)
message = "A,D,20,1,0,0,0,0,0,0,0 \r\n"
obj.send_data(message)
feed = obj.receive_data()
print(feed)
time.sleep(1)
print(5)
message = "A,D,20,1,0,0,0,0,0,0,0 \r\n"
obj.send_data(message)
feed = obj.receive_data()
print(feed)
time.sleep(1)
print(6)
file_path = "harshal.txt"
print("\n Required Dynamics : ", required_dynamics)
while not rospy.is_shutdown():
    try:
        with open(file_path, "a") as file:
            file.write(f"{required_dynamics}\n")
        if required_dynamics == 'nan':
            print('+++++++++++++++++++++++++++++++++++')
            message ="A,D,20,1,0,0,0,0,0,0,0\r\n"
            obj.send_data(message)
            time.sleep(0.5)
        if required_dynamics > 0 :
        
            print("\n Required Dynamics : ", required_dynamics)
            acc = int(required_dynamics*(20))
            if acc > 100 :
                acc = 90
            print("\n Accelerating")
            feed = obj.receive_data()
            #print(feed)
            message ="A,D,"+str(acc)+",1,0,0,0,0,0,0,0\r\n"
            print(message)
            obj.send_data(message)
            time.sleep(0.5)

        elif required_dynamics <= 0 :
            dec = int(required_dynamics*(-40))
            if dec > 90 :
                dec = 90
            print("\n Deaccelerating : ",dec)
            message = "A,D,0,1,"+str(dec)+",0,0,0,0,0,0\r\n"
            print(message)
            #message ="A,D,0,1,50,0,0,0,0,0,0\r\n"
            obj.send_data(message)
            feed = obj.receive_data()
            #print(feed)
            time.sleep(0.5)
            obj.send_data(message)
            time.sleep(0.5)
        
            
            # acc = int(required_dynamics*20)
            # print('acc value : ', acc)
            # if acc >100:
            #     print("hai")
            #     acc = 90
            # #print("\n Accelerating : ",acc)
            # message = "
            # message = "A,D,"+str(int(acc))+",0,0,0,0,0,0,0,0\r\n"
            
            # obj.send_data(message)
            # feed = obj.receive_data()
            # print(feed)
           # time.sleep(1)
        # else :
        #     dec = int(required_dynamics*(-20))
        #     if dec > 90 :
        #         dec = 90
        #     print("\n Deaccelerating : ",dec)
        #     #message = "A3,D,0,1,"+str(int(dec))+",0,0,0,0,0,0\r\n"
        #     message ="A,D,"+str(int(acc))+",0,0,0,0,0,0,0,0\r\n"
        #     obj.send_data(message)
        #     feed = obj.receive_data()
        #     print(feed)
        #     #time.sleep(1)

    except rospy.ROSInterruptException:
        pass
