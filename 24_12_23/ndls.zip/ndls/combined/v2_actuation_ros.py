import rospy
import actuator
import math
import pid
import time
from std_msgs.msg import Float64
from novatel_oem7_msgs.msg import BESTPOS, INSPVA

# Global variables
lat = 0
lng = 0
heading = 0
required_dynamics = 0  # Initialize the variable

# Open the file in append mode
file_path = "speed.txt"
speed_file = open(file_path, "a")

# Callback function for required dynamics
def callback_required_dynamics(data):
    global required_dynamics
    print(data.data)
    required_dynamics = data.data

    # Save the required dynamics value to the text file
    speed_file.write(f"{required_dynamics}\n")
    speed_file.flush()

# Callback functions for GNSS data
def callback_latlong(data):
    global lat, lng
    lat = data.lat
    lng = data.lon

def callback_heading(data):
    global heading
    heading = data.azimuth

rospy.init_node('IDM_Actuation', anonymous=True)

# ROS subscriptions
rospy.Subscriber("/novatel/oem7/bestpos", BESTPOS, callback_latlong)
rospy.Subscriber("/novatel/oem7/inspva", INSPVA, callback_heading)
rospy.Subscriber("/required_dynamics", Float64, callback_required_dynamics)

# TCP connection (uncomment and modify as needed)
# obj = your_tcp_connection_class("your_ip_address", your_port)
# obj.connect()
#TCP connection
obj = actuator.controller("169.254.178.227", 5001)
obj.connect()

# PID controller
Kp = 1.65971
Ki = 0.00007
Kd = 0.710
rate_min = -100
rate_max = 100
pid_controller = pid.PIDController(Kp, Ki, Kd, rate_min, rate_max)
message = "A,N,0,0,0,0,0,0,0,0,0\r\n" 
obj.send_data(message)
feed = obj.receive_data()
print(feed)
message = "A,N,0,1,100,0,0,0,0,0,0\r\n"
obj.send_data(message)
time.sleep(1)
feed = obj.receive_data()
print(feed)
message = "A,D,0,0,0,0,0,0,0,0,0 \r\n"
obj.send_data(message)
feed = obj.receive_data()
time.sleep(1)
print(feed)

while not rospy.is_shutdown():
    try:
        print("................................................................................................................................")
        if required_dynamics > 0:
            print("\n Accelerating : ", required_dynamics)
            acc = required_dynamics*10
            message = "A1,D,"+str(int(acc))+",0,0,1,0,0,0,0,0\r\n"
            obj.send_data(message)

            # Add your logic here using required_dynamics
            # Example: obj.send_data("A,D,0,0,0,0,0,0,0,0,0\r\n")
        else:
            # If required_dynamics is not greater than 0, perform other actions
            print("\n Deaccelerating : ", required_dynamics)
            dec = required_dynamics * 20
            if dec > 100:
                dec = 100
            message = "A3,D,0,1,"+str(int(dec))+",0,0,0,0,0,0\r\n"
            obj.send_data(message)
            # time.sleep(1)
        
    except rospy.ROSInterruptException:
        print("\n FINISH")
        # Close the file when the program finishes
        speed_file.close()
        pass
