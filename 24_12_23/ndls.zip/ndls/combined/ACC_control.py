import asyncio
import os
import time 






async def send_data():
    host = '169.254.178.227'
    port = 5001
    reader, writer = await asyncio.open_connection(host, port)
    with open('steering_feedback__300.txt', 'w') as file:
        while True:
            try:
                data = await reader.read(100)
                feedback = data.decode()
                steering_feedback = feedback.split(',')[2]
                steering_feedback = int(steering_feedback)
                #resulting_rate = pid_controller.update(steering_position, steering_feedback)
                #current_time = time.time() - start_time
                #text = "["+str(steering_feedback)+","+str(current_time)+"],\n"
                #file.write(text)
            
                #file.write(f"[{steering_feedback,current_time}],\n")
                
                message = "A1,N,0,0,0,0,0,0,0,0,0\r\n"  
                writer.write(message.encode())
                time.sleep(1)
                message = "A3,N,0,0,0,0,0,0,0,0,0\r\n"  
                writer.write(message.encode())
                #print(f"Sent: {message}")
            


                '''if int(steering_feedback) > steering_position :
                    message = "A4,N,0,0,0,1,-50,0,0,0,0\r\n"
                    writer.write(message.encode())
                    #print(f"Sent: {message}")

                elif int(steering_feedback) <= steering_position :
                    message = "A4,N,0,0,0,1,50,0,0,0,0\r\n"
                    writer.write(message.encode())
                    #print(f"Sent: {message}")
    '''

        





                


                print("\nSteering Value : ", steering_feedback)

                #writer.close()
                #await writer.wait_closed()

            except Exception as e:
                print(f"Error: {e}")

        #await asyncio.sleep(1)  # Adjust the sleep duration as needed

async def main():
    await send_data()

if __name__ == "__main__":
    asyncio.run(main())