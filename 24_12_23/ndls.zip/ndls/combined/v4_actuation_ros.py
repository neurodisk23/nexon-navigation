import rospy
import actuator
import math
import pid
from std_msgs.msg import Float64
from novatel_oem7_msgs.msg import BESTPOS, INSPVA
import asyncio
import os
import time

# Global variables
lat = 0
lng = 0
heading = 0
required_dynamics = 0  # Initialize the variable

# Open the file in append mode
file_path = "speed.txt"
speed_file = open(file_path, "a")

# TCP connection variables
host = '169.254.178.227'
port = 5001
reader = None
writer = None

# Callback function for required dynamics
def callback_required_dynamics(data):
    global required_dynamics
    required_dynamics = data.data

    # Save the required dynamics value to the text file
    speed_file.write(f"{required_dynamics}\n")
    speed_file.flush()

# Callback functions for GNSS data
def callback_latlong(data):
    global lat, lng
    lat = data.lat
    lng = data.lon

def callback_heading(data):
    global heading
    heading = data.azimuth

rospy.init_node('IDM_Actuation', anonymous=True)

# ROS subscriptions
rospy.Subscriber("/novatel/oem7/bestpos", BESTPOS, callback_latlong)
rospy.Subscriber("/novatel/oem7/inspva", INSPVA, callback_heading)
rospy.Subscriber("/required_dynamics", Float64, callback_required_dynamics)

async def send_data():
    global writer
    try:
        reader, writer = await asyncio.open_connection(host, port)
        message = "A,N,0,0,0,0,0,0,0,0,0\r\n" 
        writer.write(message.encode())
        message = "A,N,0,1,100,0,0,0,0,0,0\r\n"
        writer.write(message.encode())
        time.sleep(1)
        message = "A,D,0,0,0,0,0,0,0,0,0 \r\n"
        writer.write(message.encode())
        time.sleep(1)
        while True:
            message = "A1,D,0,0,0,0,0,0,0,0,0\r\n"  
            writer.write(message.encode())
            print("\n Required Dynamics: ", required_dynamics)
            # Adjust the sleep duration as needed
    except KeyboardInterrupt:
        print("KeyboardInterrupt: Closing the connection...")
       
async def main():
    await send_data()

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("KeyboardInterrupt: Exiting the program...")
        if writer:
            writer.close()
        asyncio.run(writer.wait_closed())
