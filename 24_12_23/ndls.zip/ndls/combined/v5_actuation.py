import rospy
import actuator
import math
import pid
import time
from std_msgs.msg import Float64
from novatel_oem7_msgs.msg import BESTPOS, INSPVA
import asyncio
import os
import time 

# Global variables
lat = 0
lng = 0
heading = 0
required_dynamics = 0  # Initialize the variable

# Open the file in append mode
file_path = "speed.txt"
speed_file = open(file_path, "a")\



    

# Callback function for required dynamics
def callback_required_dynamics(data):
    global required_dynamics
    print(data.data)
    required_dynamics = data.data

    # Save the required dynamics value to the text file
    speed_file.write(f"{required_dynamics}\n")
    speed_file.flush()

# Callback functions for GNSS data
def callback_latlong(data):
    global lat, lng
    lat = data.lat
    lng = data.lon

def callback_heading(data):
    global heading
    heading = data.azimuth

rospy.init_node('IDM_Actuation', anonymous=True)

# ROS subscriptions
rospy.Subscriber("/novatel/oem7/bestpos", BESTPOS, callback_latlong)
rospy.Subscriber("/novatel/oem7/inspva", INSPVA, callback_heading)
rospy.Subscriber("/required_dynamics", Float64, callback_required_dynamics)



async def open_connection(host, port):
    print(f"Opening connection to {host}:{port}")
    reader, writer = await asyncio.open_connection(host, port)
    print("Connection opened")
    return reader, writer

async def close_connection(reader, writer):
    print("Closing connection")
    writer.close()
    await writer.wait_closed()
    print("Connection closed")

async def main():
    host = '169.254.178.227'
    port = 5001
    reader, writer = await open_connection(host, port)

    try:
        message = "A,N,0,0,0,0,0,0,0,0,0\r\n" 
        writer.write(message.encode())
        message = "A,N,0,1,80,0,0,0,0,0,0\r\n"
        writer.write(message.encode())
        time.sleep(1.5)
        message = "A,D,0,0,0,0,0,0,0,0,0 \r\n"
        writer.write(message.encode())
        time.sleep(1)
        # Your main program logic goes here
        while True:
            print("\n Required Dynamics : ", required_dynamics)
            if required_dynamics >= 0 :
                acc = int(required_dynamics*5)
                if acc >100:
                    acc = 100
                print("\nAccelerating : ",acc)
                message = "A1,D,"+str(acc)+",0,0,0,0,0,0,0,0\r\n"
                writer.write(message.encode())

                
            else :
                
                dec = int(required_dynamics*(-20))
                if dec > 90 :
                    dec = 90
                print("\n Deaccelerating : ",dec)
                message = "A3,D,0,1,"+str(dec)+",0,0,0,0,0,0\r\n"
                writer.write(message.encode())
          
            

    except KeyboardInterrupt:
        print("KeyboardInterrupt: Cleaning up and exiting...")
        await close_connection(reader, writer)

    finally:
        # Cleanup actions go here
        await close_connection(reader, writer)

if __name__ == "__main__":
    asyncio.run(main())
