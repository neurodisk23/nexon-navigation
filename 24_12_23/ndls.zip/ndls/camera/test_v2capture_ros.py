import cv2
import numpy as np
import numpy
import rospy
from std_msgs.msg import String
from std_msgs.msg import Float64
import pyzed.sl as sl
inter = cv2.INTER_AREA
font = cv2.FONT_HERSHEY_SIMPLEX



def create_bottom_trapezium_mask(width, height, top_width_percent, bottom_width_percent, height_percent):
    mask = np.zeros((height, width), dtype=np.uint8)
    
    top_width = int(width * top_width_percent / 100)
    bottom_width = int(width * bottom_width_percent / 100)
    height = int(height * height_percent / 100)
    
    # Define the trapezium vertices at the bottom of the frame
    vertices = np.array([
        [width // 2 - bottom_width // 2 + 20, 720],
        [width // 2 + bottom_width // 2 - 100 , 720],
        [width // 2 + top_width // 2,450],
        [width // 2 - top_width - 30 // 2, 450]
    ], dtype=np.int32)
    
    # Fill the trapezium with white color (255)
    cv2.fillPoly(mask, [vertices], 255)
    
    return mask


def get_pixel_position(x, y, trapezium_mask):
    if trapezium_mask[y, x] == 255:
        return "Inside drivespace "
    elif x < trapezium_mask.shape[1] // 2:
        return "Left Side of Drive Space"
    else:
        return "Right Side of Drive Space"





def main() :

    # Creating the ros publisher 

    pub_identity = rospy.Publisher("detection_object", String, queue_size = 10)
    pub_gap = rospy.Publisher("Vehicle_Gap", Float64, queue_size = 10)
    pub_velocity = rospy.Publisher("Vehicle_speed_m/sec", Float64, queue_size = 10)
    rospy.init_node("camera_data", anonymous = True)
    rate = rospy.Rate(10)

    # Create a ZED camera object
    zed = sl.Camera()
    init_params = sl.InitParameters()
    init_params.depth_mode = sl.DEPTH_MODE.PERFORMANCE
    init_params.coordinate_units = sl.UNIT.METER
    init_params.sdk_verbose = 1

    # Open the camera
    err = zed.open(init_params)
    if err != sl.ERROR_CODE.SUCCESS :
        print(repr(err))
        zed.close()
        exit(1)

    # Display help in console
  

    # Set runtime parameters after opening the camera
    runtime = sl.RuntimeParameters()

    # Prepare new image size to retrieve half-resolution images
    image_size = zed.get_camera_information().camera_configuration.resolution
    image_size.width = image_size.width /2
    image_size.height = image_size.height /2

    # Declare your sl.Mat matrices
    image_zed = sl.Mat(image_size.width, image_size.height, sl.MAT_TYPE.U8_C4)
    depth_image_zed = sl.Mat(image_size.width, image_size.height, sl.MAT_TYPE.U8_C4)
    point_cloud = sl.Mat()





    obj_param = sl.ObjectDetectionParameters()
    obj_param.enable_tracking=True
    obj_param.enable_segmentation=True
    obj_param.detection_model = sl.OBJECT_DETECTION_MODEL.MULTI_CLASS_BOX_MEDIUM
    if obj_param.enable_tracking :
        positional_tracking_param = sl.PositionalTrackingParameters()
        #positional_tracking_param.set_as_static = True
        zed.enable_positional_tracking(positional_tracking_param)

    print("Object Detection: Loading Module...")

    err = zed.enable_object_detection(obj_param)
    if err != sl.ERROR_CODE.SUCCESS :
        print("Enable object detection : "+repr(err)+". Exit program.")
        zed.close()
        exit()

    objects = sl.Objects()
    obj_runtime_param = sl.ObjectDetectionRuntimeParameters()
    obj_runtime_param.detection_confidence_threshold = 60



    key = ' '
    while key != 113 :
        err = zed.grab(runtime)
        if err == sl.ERROR_CODE.SUCCESS :
            zed.grab()
            zed.retrieve_objects(objects,obj_runtime_param)
            if objects.is_new:
                obj_array = objects.object_list
                print(str(len(obj_array))+" Object(s) detected\n")
                if len(obj_array) > 0 :
                    for i in range(len(obj_array)):
                        first_object = obj_array[i]
                        print("\n \nobject attributes:")
                        print(" Label '"+repr(first_object.label)+"' (conf. "+str(int(first_object.confidence))+"/100)")
                        if obj_param.enable_tracking :
                            print(" Tracking ID: "+str(int(first_object.id))+" tracking state: "+repr(first_object.tracking_state)+" / "+repr(first_object.action_state))
                        position = first_object.position
                        relative_gap = np.sqrt(position[0]**2 + position[1]**2 + position[2]**2)
                        velocity = first_object.velocity
                        relative_velocity = np.sqrt(velocity[0]**2 + velocity[1]**2 + velocity[2]**2)
                        dimensions = first_object.dimensions
                        print(" 3D position: [{0},{1},{2}]\n Velocity: [{3},{4},{5}]\n 3D dimentions: [{6},{7},{8}]".format(position[0],position[1],position[2],velocity[0],velocity[1],velocity[2],dimensions[0],dimensions[1],dimensions[2]))
                        if first_object.mask.is_init():
                            print(" 2D mask available")

                        print(" Bounding Box 2D ")
                        bounding_box_2d = first_object.bounding_box_2d
                        for it in bounding_box_2d :
                            print("    "+str(it),end='')
                        x = bounding_box_2d[0][0]
                        y = bounding_box_2d[0][1]
                        w = bounding_box_2d[1][0] - bounding_box_2d[0][0]
                        h = bounding_box_2d[3][1] - bounding_box_2d[0][1]
                        print("\n Bounding Box 3D ")
                        bounding_box = first_object.bounding_box
                        for it in bounding_box :
                            print("    "+str(it),end='')
                        zed.retrieve_image(image_zed, sl.VIEW.LEFT, sl.MEM.CPU, image_size)
                        zed.retrieve_image(depth_image_zed, sl.VIEW.DEPTH, sl.MEM.CPU, image_size)
                        # Retrieve the RGBA point cloud in half resolution
                        zed.retrieve_measure(point_cloud, sl.MEASURE.XYZRGBA, sl.MEM.CPU, image_size)

                        # To recover data from sl.Mat to use it with opencv, use the get_data() method
                        # It returns a numpy array that can be used as a matrix with opencv
                        image_ocv = image_zed.get_data()
                        depth_image_ocv = depth_image_zed.get_data()
                        image_ocv = cv2.resize(image_ocv, (1280,720), interpolation = inter)
                        text = str(repr(first_object.label)) + " ID "+ str(int(first_object.id))
                        pub_identity.publish(text)
                        pub_gap.publish(relative_gap)
                        pub_velocity.publish(relative_velocity)
                        rate.sleep()
                        cv2.putText(image_ocv, text, (int(x),int(y)- 7), font, 1, (255,0, 0), 3, cv2.LINE_AA)
                        
                        img_ocv = cv2.rectangle(image_ocv,(int(x),int(y)),(int(x+w),int(y+h)),(0,255,0),2)


                        height, width, _ = image_ocv.shape
                        print("\n frame height ...........", height, width)
                        # Create a trapezium mask at the bottom of the frame
                        bottom_trapezium_mask = create_bottom_trapezium_mask(width, height, top_width_percent=3, bottom_width_percent=50, height_percent=30)

                        # Apply the mask to the image
                        result = cv2.bitwise_and(image_ocv, image_ocv, mask=bottom_trapezium_mask)

                        # Check if a pixel is in the road region
                        pixel_x = int(x + w/2)  # Example pixel coordinates
                        pixel_y = int(y + h/2)
                        position = get_pixel_position(pixel_x, pixel_y, bottom_trapezium_mask)

                        print(f"Detection position: {position}")

                        # Display the original image, mask, and result
                    
                        #cv2.imshow('Road Mask', bottom_trapezium_mask)
                        cv2.imshow('Result', result)

                        cv2.imshow("Image", image_ocv)
                        #cv2.imshow("Depth", depth_image_ocv)

                        key = cv2.waitKey(10)


    cv2.destroyAllWindows()
    zed.close()

    print("\nFINISH")

if __name__ == "__main__":
    main()

