import cv2
import numpy as np
import numpy
import rospy
from std_msgs.msg import String
from std_msgs.msg import Float64
import pyzed.sl as sl
inter = cv2.INTER_AREA
font = cv2.FONT_HERSHEY_SIMPLEX
center_occupancy = 0
left_occupancy = 0
right_occupancy = 0
vehicle_position = 0

def create_bottom_trapezium_mask(width, height, top_width_percent, bottom_width_percent, height_percent):
    mask = np.zeros((height, width), dtype=np.uint8)
    
    top_width = int(width * top_width_percent / 100)
    bottom_width = int(width * bottom_width_percent / 100)
    height = int(height * height_percent / 100)
    
    # Define the trapezium vertices at the bottom of the frame
    vertices = np.array([
        [width // 2 - bottom_width // 2 + 20, 720],
        [width // 2 + bottom_width // 2 - 100 , 720],
        [width // 2 + top_width // 2,450],
        [width // 2 - top_width - 30 // 2, 450]
    ], dtype=np.int32)
    
    # Fill the trapezium with white color (255)
    cv2.fillPoly(mask, [vertices], 255)
    
    return mask


def orientation(p,width, height, top_width_percent, bottom_width_percent, height_percent):
    """
    Determine the orientation of point c with respect to the line formed by points a and b.

    Parameters:
    - a, b, c: Tuple (x, y) representing pixel coordinates.

    Returns:
    - 1 if c is to the left of the line (a, b)
    - -1 if c is to the right of the line (a, b)
    - 0 if c is on the line (a, b)
    """
    top_width = int(width * top_width_percent / 100)
    bottom_width = int(width * bottom_width_percent / 100)
    height = int(height * height_percent / 100)
    
    a = [width // 2 - bottom_width // 2 + 20, 720]
    b = [width // 2 + bottom_width // 2 - 100 , 720]
    c = [width // 2 - top_width - 30 // 2, 450]
    d = [width // 2 + top_width // 2,450]



    val = (b[1] - a[1]) * (p[0] - b[0]) - (b[0] - a[0]) * (p[1] - b[1])
    if val > 0:
        return 1  # c is to the left
    elif val < 0:
        return -1  # c is to the right
    else:
        return 0 










def get_pixel_position(x, y, trapezium_mask):
    if trapezium_mask[y, x] == 255:
        center_occupancy = 1
        
        return "Central Drive Space Occupied"
        
    elif x < trapezium_mask.shape[1] // 2:
        left_occupancy = 1
        
        return "Left Side of Drive Space"
    else:
        right_occupancy = 1
        
        return "Right Side of Drive Space"


def draw_bounding_boxes(bounding_boxes, image):
    """
    Draw bounding boxes on an image.

    Parameters:
    - bounding_boxes: A list containing multiple [x, y, w, h] coordinates.
    - image: The input image frame.

    Returns:
    - image with bounding boxes drawn.
    """
    # Create a copy of the image to avoid modifying the original
    result_image = np.copy(image)

    # Convert the image to BGR format if it is in grayscale
    if len(result_image.shape) == 2:
        result_image = cv2.cvtColor(result_image, cv2.COLOR_GRAY2BGR)

    # Draw bounding boxes on the image
    for box in bounding_boxes:
        x, y, w, h = box
        color = (0, 255, 0)  # BGR color for the bounding box (green in this case)
        thickness = 2  # Thickness of the bounding box lines

        # Draw the bounding box rectangle
        result_image = cv2.rectangle(result_image, (x, y), (x + w, y + h), color, thickness)

    return result_image





def main() :

    # Creating the ros publisher 

    pub_identity = rospy.Publisher("detection_object", String, queue_size = 10)
    pub_left_lane_occupancy = rospy.Publisher("left_lane_occupancy", Float64,  queue_size =10)
    pub_center_lane_occupancy = rospy.Publisher("center_lane_occupancy", Float64,  queue_size =10)
    pub_right_lane_occupancy = rospy.Publisher("right_lane_occupancy", Float64,  queue_size =10)

    pub_gap = rospy.Publisher("Vehicle_Gap", Float64, queue_size = 10)
    pub_velocity = rospy.Publisher("Vehicle_speed_m/sec", Float64, queue_size = 10)
    rospy.init_node("camera_data", anonymous = True)
    rate = rospy.Rate(10)

    # Create a ZED camera object
    zed = sl.Camera()
    init_params = sl.InitParameters()
    init_params.depth_mode = sl.DEPTH_MODE.PERFORMANCE
    init_params.coordinate_units = sl.UNIT.METER
    init_params.sdk_verbose = 1

    # Open the camera
    err = zed.open(init_params)
    if err != sl.ERROR_CODE.SUCCESS :
        print(repr(err))
        zed.close()
        exit(1)

    # Display help in console
  

    # Set runtime parameters after opening the camera
    runtime = sl.RuntimeParameters()

    # Prepare new image size to retrieve half-resolution images
    image_size = zed.get_camera_information().camera_configuration.resolution
    image_size.width = image_size.width /2
    image_size.height = image_size.height /2

    # Declare your sl.Mat matrices
    image_zed = sl.Mat(image_size.width, image_size.height, sl.MAT_TYPE.U8_C4)
    depth_image_zed = sl.Mat(image_size.width, image_size.height, sl.MAT_TYPE.U8_C4)
    point_cloud = sl.Mat()





    obj_param = sl.ObjectDetectionParameters()
    obj_param.enable_tracking=True
    obj_param.enable_segmentation=True
    obj_param.detection_model = sl.OBJECT_DETECTION_MODEL.MULTI_CLASS_BOX_MEDIUM
    if obj_param.enable_tracking :
        positional_tracking_param = sl.PositionalTrackingParameters()
        #positional_tracking_param.set_as_static = True
        zed.enable_positional_tracking(positional_tracking_param)

    print("Object Detection: Loading Module...")

    err = zed.enable_object_detection(obj_param)
    if err != sl.ERROR_CODE.SUCCESS :
        print("Enable object detection : "+repr(err)+". Exit program.")
        zed.close()
        exit()

    objects = sl.Objects()
    obj_runtime_param = sl.ObjectDetectionRuntimeParameters()
    obj_runtime_param.detection_confidence_threshold = 60



    key = ' '
    while key != 113 :
        err = zed.grab(runtime)
        if err == sl.ERROR_CODE.SUCCESS :
            zed.grab()
            zed.retrieve_objects(objects,obj_runtime_param)
            if objects.is_new:
                obj_array = objects.object_list
                print(str(len(obj_array))+" Object(s) detected\n")
                if len(obj_array) > 0 :
                    for i in range(len(obj_array)):
                        bb_list = []
                        first_object = obj_array[i]
                        print("\n \nobject attributes:")
                        print(" Label '"+repr(first_object.label)+"' (conf. "+str(int(first_object.confidence))+"/100)")
                        if obj_param.enable_tracking :
                            print(" Tracking ID: "+str(int(first_object.id))+" tracking state: "+repr(first_object.tracking_state)+" / "+repr(first_object.action_state))
                        position = first_object.position
                        relative_gap = np.sqrt(position[0]**2 + position[1]**2 + position[2]**2)
                        velocity = first_object.velocity
                        relative_velocity = np.sqrt(velocity[0]**2 + velocity[1]**2 + velocity[2]**2)
                        dimensions = first_object.dimensions
                        print(" 3D position: [{0},{1},{2}]\n Velocity: [{3},{4},{5}]\n 3D dimentions: [{6},{7},{8}]".format(position[0],position[1],position[2],velocity[0],velocity[1],velocity[2],dimensions[0],dimensions[1],dimensions[2]))
                        if first_object.mask.is_init():
                            print(" 2D mask available")
                        print(" Bounding Box 2D ")
                        bounding_box_2d = first_object.bounding_box_2d
                        for it in bounding_box_2d :
                            print("    "+str(it),end='')
                        x = bounding_box_2d[0][0]
                        y = bounding_box_2d[0][1]
                        w = bounding_box_2d[1][0] - bounding_box_2d[0][0]
                        h = bounding_box_2d[3][1] - bounding_box_2d[0][1]
                        value = [int(x),int(y),int(w),int(h)]
                        bb_list.append(value)
                        
                        print("\n Bounding Box 3D ")
                        bounding_box = first_object.bounding_box
                        for it in bounding_box :
                            print("    "+str(it),end='')
                        text = str(repr(first_object.label)) + " ID "+ str(int(first_object.id))
                        pub_identity.publish(text)
                        pub_gap.publish(relative_gap)
                        pub_velocity.publish(relative_velocity)
                        pub_center_lane_occupancy.publish(center_occupancy)
                        pub_left_lane_occupancy.publish(left_occupancy)
                        pub_right_lane_occupancy.publish(right_occupancy)
                        rate.sleep()


                    zed.retrieve_image(image_zed, sl.VIEW.LEFT, sl.MEM.CPU, image_size)
                    zed.retrieve_image(depth_image_zed, sl.VIEW.DEPTH, sl.MEM.CPU, image_size)
                    # Retrieve the RGBA point cloud in half resolution
                    zed.retrieve_measure(point_cloud, sl.MEASURE.XYZRGBA, sl.MEM.CPU, image_size)

                    # To recover data from sl.Mat to use it with opencv, use the get_data() method
                    # It returns a numpy array that can be used as a matrix with opencv
                    image_ocv = image_zed.get_data()
                    depth_image_ocv = depth_image_zed.get_data()
                    image_ocv = cv2.resize(image_ocv, (1280,720), interpolation = inter)
                    
                    image_ocv = draw_bounding_boxes(bb_list,image_ocv)
                    height, width, _ = image_ocv.shape

                    # Create a trapezium mask at the bottom of the frame
                    bottom_trapezium_mask = create_bottom_trapezium_mask(width, height, top_width_percent=3, bottom_width_percent=50, height_percent=30)
                    

                    print("\n Detection shape:.......................................................................",bottom_trapezium_mask.shape)

                    # Apply the mask to the image
                    result = cv2.bitwise_and(image_ocv, image_ocv, mask=bottom_trapezium_mask)

                    # Check if a pixel is in the road region
                    pixel_x = int(x + w/2)  # Example pixel coordinates
                    pixel_y = int(y + h/2)
                    position = get_pixel_position(pixel_x, pixel_y, bottom_trapezium_mask)
                    ori = orientation([pixel_x,  pixel_y],width, height, top_width_percent=3, bottom_width_percent=50, height_percent=30 )
                    print("\n Orientation $$$$$$$$$$$$$$$$$$$$", ori)
                    print(f"Detection position: {position}")

                    # Display the original image, mask, and result
                
                    #cv2.imshow('Road Mask', bottom_trapezium_mask)
                    cv2.imshow('Result', result)

                    cv2.imshow("Image", image_ocv)
                    #cv2.imshow("Depth", depth_image_ocv)

                    key = cv2.waitKey(10)


    cv2.destroyAllWindows()
    zed.close()

    print("\nFINISH")

if __name__ == "__main__":
    main()

